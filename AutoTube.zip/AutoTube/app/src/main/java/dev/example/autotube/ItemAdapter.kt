package dev.example.autotube

import android.content.Context
import android.graphics.Color
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import coil.load

class ItemAdapter(private val ctx: Context) : BaseAdapter() {
    private var items: List<Item> = emptyList()

    fun set(list: List<Item>) { items = list; notifyDataSetChanged() }
    override fun getCount() = items.size
    override fun getItem(position: Int) = items[position]
    override fun getItemId(position: Int) = position.toLong()

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun build(): LinearLayout {
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val img = ImageView(ctx).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.LTGRAY)
        }
        row.addView(img, LinearLayout.LayoutParams(dp(150), dp(84)))
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
        }
        col.addView(TextView(ctx).apply { textSize = 15f; maxLines = 3; setTextColor(Color.BLACK) })
        col.addView(TextView(ctx).apply { textSize = 13f; maxLines = 1; setTextColor(Color.DKGRAY) })
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        return row
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val row = (convertView as? LinearLayout) ?: build()
        val item = items[position]
        val img = row.getChildAt(0) as ImageView
        val col = row.getChildAt(1) as LinearLayout
        (col.getChildAt(0) as TextView).text = item.title
        (col.getChildAt(1) as TextView).text = item.subtitle
        if (item.thumb.isNotEmpty()) img.load(item.thumb) else img.setImageDrawable(null)
        return row
    }
}
